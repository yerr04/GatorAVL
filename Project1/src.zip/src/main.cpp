#include <iostream>
#include "AVLTree.h"


/* Note: 
	1. You will have to comment main() when unit testing your code because catch uses its own main().
	2. You will submit this main.cpp file and any header files you have on Gradescope. 
*/

int main(){
	AVLTree tree;

	// number of commands to be executed
	int commandNum = 0;
	cin >> commandNum;

	// execute commands
	string command;
	while (commandNum > 0) {
		cin >> command;  // Moved inside the loop to read a new command each iteration
		if (command == "insert") {
			string name, id;
			cin.ignore();  // Ignore the whitespace character following the command
			// get rid of the quotes
			getline(cin, name, '"');
			getline(cin, name, '"');
			cin >> id;  // Changed to cin to avoid reading newline characters
			if (id.length() != 8) {  // Check if id is exactly 8 digits
				cout << "unsuccessful" << endl;
			}
			else {
				tree.insertNameID(name, id);
			}
		}
		else if (command == "remove") {
			string id;
			cin >> id;
			if (id.length() != 8) {  // Check if id is exactly 8 digits
				cout << "unsuccessful" << endl;
			}
			else {
				tree.removeID(id);
			}
		}
		else if (command == "search") {
			cin.ignore();  // Ignore any whitespace following the command
			if (cin.peek() == '"') {
				string name;
				// get rid of the quotes
				getline(cin, name, '"');
				getline(cin, name, '"');
				tree.searchName(name);
			}
			else {
				string id;
				cin >> id;
				if (id.length() != 8) {  // Check if id is exactly 8 digits
					cout << "unsuccessful" << endl;
					commandNum--;
					continue;  // Skip the rest of this iteration and move to the next command
				}
				tree.searchID(id);
			}
		}
		else if (command == "printInorder") {
			tree.printInOrder();
		}
		else if (command == "printPreOrder") {
			tree.printPreOrder();
		}
		else if (command == "printPostOrder") {
			tree.printPostOrder();
		}
		else if (command == "printLevelCount") {
			tree.printLevelCount();
		}
		else if (command == "removeInorder") {
			int n;
			cin >> n;
			tree.removeInOrder(n);
		}
		else {
			cout << "unsuccessful" << endl;
		}
		commandNum--;
	}
	return 0;
}

// TODO:
// input parsing
// unit tests